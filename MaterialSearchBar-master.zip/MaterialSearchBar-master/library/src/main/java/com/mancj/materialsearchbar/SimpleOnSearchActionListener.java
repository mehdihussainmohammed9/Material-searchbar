package com.mancj.materialsearchbar;

/**
 * Created by mancj on 26.01.17.
 */

public abstract class SimpleOnSearchActionListener implements MaterialSearchBar.OnSearchActionListener {

    @Override
    public void onSearchStateChanged(boolean enabled) {

    }

    @Override
    public void onSearchConfirmed(CharSequence text) {

    }

    @Override
    public void onButtonClicked(int buttonCode) {

    }
}
